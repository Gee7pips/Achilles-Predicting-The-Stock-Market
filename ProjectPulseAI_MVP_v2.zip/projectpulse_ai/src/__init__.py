"""
ProjectPulse.AI source package
"""